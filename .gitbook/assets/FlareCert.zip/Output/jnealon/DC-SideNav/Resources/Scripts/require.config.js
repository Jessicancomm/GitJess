require.config({
    urlArgs: 't=637504671124014694'
});